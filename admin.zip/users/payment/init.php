<?php

require "Coin.php";
require "vendor/autoload.php";

require "Payment.php";

$coin = new CoinPaymentsAPI();
$coin->Setup("5db1f98bEe298BDE6a7bA6aE3C96c61F97e47dD502De6C5E0949ec82b88B1fF2","149b381625427ca2d3f397655f2d59f115667d1f8da80b3092a8fbd030e3e99a");