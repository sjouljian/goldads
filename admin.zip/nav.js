document.getElementById("navMenu").innerHTML =
'<div class="container-fluid" style="background-color: #007c88;">'+
      '<div class="row">'+
          '<div class="col-12">'+
            '<nav class="navbar navbar-expand-md navbar-light py-3">'+
            '<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">'+
                '<span class="navbar-toggler-icon"></span>'+
            '</button>'+
            '<div class="collapse navbar-collapse  justify-content-center" id="navbarCollapse">'+
                '<div class="navbar-nav">'+
                    '<a href="index.php" class="nav-item nav-link text-light px-3">Home</a>'+
                    '<a href="how.php" class="nav-item nav-link text-light px-3">How It Work</a>'+
                    '<a href="faq.php" class="nav-item nav-link text-light px-3">F.A.Q</a>'+
                    '<a href="rules.php" class="nav-item nav-link text-light px-3">Rules</a>'+
                    '<a href="login.php" class="nav-item nav-link text-light px-3">Login</a>'+
                    
                '</div>'+ 
            '</div>'+
            '</nav>'+



     '</div>'+
    '</div>'+
'</div>'