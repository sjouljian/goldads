<?php
session_start();
$db=mysqli_connect('localhost','goldadsp_mainuse','rTRcw)23K0q~','goldadsp_main');
if($db){
	//echo "Database Connected";
}else{
	mysqli_error($db);
}

 ?>
