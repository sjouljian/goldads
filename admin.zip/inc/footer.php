<!-- coming soon counter -->

<nav id="footer"></nav>
    <script src="foot.js"></script>
