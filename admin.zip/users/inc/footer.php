<div class="container-fluid mb-3"  style="background-color: #007c88;">
    <div class="container">
        <div class="row">
        <div class="col-xl-4 col-md-4 col-sm-12 my-2 text-center d-block">
         <img src="../assets/img/BTC.png" alt="" class="l">  <img src="../assets/img/ETH.png" alt="" class="l">  <img src="../assets/img/LTC.png" alt="" class="l">  <img src="../assets/img/cpay.png" alt="" class="l">
        </div>
        <div class="col-xl-8 col-md-8 col-sm-12 my-2 text-center d-block font-weight-bold">
          @2020<span style="color: goldenrod;">Gold</span> <span style="color: red;">Ads</span> <span style="color:black;">Pack</span> <br><span> Developed by:  <a href="https://www.fiverr.com/shahramawan0?up_rollout=true" style="color: white;">Shahram Awan</a></span>
        </div>
        </div>
    </div>
</div>