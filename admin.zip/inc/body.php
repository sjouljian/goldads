<!-- header logo section -->
<div class="container-fluid" style="background-color: #007c88;">
    <div class="container">
        <div class="row">
           <div class="col-6">
               <img src="logo.png" id="l-logo"  onclick="window.location.href='index.php#slider';" height="70px" width="70px"/>
               <br>
               <span class="font-weight-bold" style="color: goldenrod;">Gold</span> <span  class="font-weight-bold" style="color:red;">Ads</span> <span   class="font-weight-bold"style="color:black;">Pack</span>
           </div>

           


        </div>
      
    </div>

</div>
<!-- header navigation section -->
<nav id="navMenu"></nav>
    <script src="nav.js"></script>
